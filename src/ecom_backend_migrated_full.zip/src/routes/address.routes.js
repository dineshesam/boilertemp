import express from 'express';
import { listAddresses, addAddress, updateAddress, deleteAddress } from '../controllers/address.controller.js';
const router = express.Router();
router.get('/:userId', listAddresses);
router.post('/:userId', addAddress);
router.put('/:id', updateAddress);
router.delete('/:id', deleteAddress);
export default router;
