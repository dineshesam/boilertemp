import express from 'express';
import { createOrder, listOrders } from '../controllers/order.controller.js';
const router = express.Router();
router.post('/', createOrder);
router.get('/:userId', listOrders);
export default router;
