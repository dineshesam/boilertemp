import express from 'express';
import { getWishlist, toggleWishlist } from '../controllers/wishlist.controller.js';
const router = express.Router();
router.get('/:userId', getWishlist);
router.post('/:userId/toggle', toggleWishlist);
export default router;
