import express from 'express';
import { getCart, addToCart, removeFromCart } from '../controllers/cart.controller.js';
const router = express.Router();
router.get('/:userId', getCart);
router.post('/:userId/add', addToCart);
router.post('/:userId/remove', removeFromCart);
export default router;
