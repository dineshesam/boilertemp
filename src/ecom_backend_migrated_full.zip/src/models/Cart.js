import mongoose from 'mongoose';
const { Schema, model } = mongoose;

const CartItem = new Schema({
  product: { type: Schema.Types.ObjectId, ref: 'Product' },
  qty: { type: Number, default: 1 },
  price: Number,
}, { _id: false });

const CartSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', unique: true },
  items: [CartItem],
  total: { type: Number, default: 0 },
}, { timestamps: true });

export default model('Cart', CartSchema);
