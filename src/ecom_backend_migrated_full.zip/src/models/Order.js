import mongoose from 'mongoose';
const { Schema, model } = mongoose;

const OrderItem = new Schema({
  product: { type: Schema.Types.ObjectId, ref: 'Product' },
  title: String,
  qty: Number,
  price: Number,
}, { _id: false });

const OrderSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User' },
  items: [OrderItem],
  shippingAddress: Object,
  status: { type: String, default: 'pending' },
  total: Number,
  payment: Object,
}, { timestamps: true });

export default model('Order', OrderSchema);
