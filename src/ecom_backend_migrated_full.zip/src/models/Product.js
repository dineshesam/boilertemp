import mongoose from 'mongoose';
const { Schema, model } = mongoose;

const ProductSchema = new Schema({
  title: { type: String, required: true },
  slug: { type: String, index: true },
  description: String,
  price: { type: Number, required: true },
  images: [String], // store Cloudinary URLs
  stock: { type: Number, default: 0 },
  category: String,
  brand: String,
  active: { type: Boolean, default: true },
}, { timestamps: true });

export default model('Product', ProductSchema);
