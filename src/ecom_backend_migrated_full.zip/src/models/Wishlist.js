import mongoose from 'mongoose';
const { Schema, model } = mongoose;

const WishlistSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User', unique: true },
  products: [{ type: Schema.Types.ObjectId, ref: 'Product' }],
}, { timestamps: true });

export default model('Wishlist', WishlistSchema);
