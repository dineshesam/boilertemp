import mongoose from 'mongoose';
const { Schema, model } = mongoose;

const AddressSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User' },
  fullName: String,
  phone: String,
  addressLine1: String,
  addressLine2: String,
  city: String,
  state: String,
  zip: String,
  country: String,
}, { timestamps: true });

export default model('Address', AddressSchema);
