import dotenv from 'dotenv';
import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';
import User from '../models/User.js';
import Product from '../models/Product.js';
import Cart from '../models/Cart.js';
import Order from '../models/Order.js';
import Address from '../models/Address.js';
import Wishlist from '../models/Wishlist.js';

dotenv.config();
const uri = process.env.MONGODB_URI;
if(!uri) {
  console.error('Set MONGODB_URI in env before running migration');
  process.exit(1);
}

async function loadJson(name) {
  const p = path.resolve(new URL('.', import.meta.url).pathname, '../data', name);
  if(!fs.existsSync(p)) return null;
  const raw = fs.readFileSync(p, 'utf8');
  return JSON.parse(raw);
}

async function main(){
  await mongoose.connect(uri);
  console.log('connected for migration');
  // users.json
  const users = await loadJson('users.json') || await loadJson('Users.json') || [];
  for(const u of users){
    try {
      await User.updateOne({ email: u.email }, { $setOnInsert: { name: u.name || u.username || u.email, email: u.email, passwordHash: u.passwordhash || u.passwordHash || 'changeme' } }, { upsert: true });
    } catch(e){ console.error('user import err', e); }
  }
  // products.json
  const products = await loadJson('products.json') || await loadJson('Products.json') || [];
  for(const p of products){
    try{
      const doc = {
        title: p.title || p.name,
        slug: p.slug || p.id,
        description: p.description || p.desc || '',
        price: parseFloat(p.price) || 0,
        images: p.images || (p.image ? [p.image] : []),
        stock: p.stock || p.quantity || 0,
        category: p.category || '',
        brand: p.brand || '',
        active: true
      };
      await Product.updateOne({ title: doc.title }, { $set: doc }, { upsert: true });
    }catch(e){ console.error('product import err', e); }
  }
  console.log('migration complete');
  process.exit(0);
}

main().catch(e=>{ console.error(e); process.exit(1); });
