import Address from '../models/Address.js';

export const listAddresses = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    const addresses = await Address.find({ user: userId });
    res.json(addresses);
  } catch (err) { next(err); }
};

export const addAddress = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    const data = req.body;
    const a = await Address.create({ user: userId, ...data });
    res.json(a);
  } catch (err) { next(err); }
};

export const updateAddress = async (req, res, next) => {
  try {
    const id = req.params.id;
    const a = await Address.findByIdAndUpdate(id, req.body, { new: true });
    res.json(a);
  } catch (err) { next(err); }
};

export const deleteAddress = async (req, res, next) => {
  try {
    await Address.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (err) { next(err); }
};
