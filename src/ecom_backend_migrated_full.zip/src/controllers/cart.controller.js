import Cart from '../models/Cart.js';
import Product from '../models/Product.js';

export const getCart = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    let cart = await Cart.findOne({ user: userId }).populate('items.product');
    if(!cart) return res.json({ items: [] });
    res.json(cart);
  } catch (err) { next(err); }
};

export const addToCart = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    const { productId, qty } = req.body;
    let cart = await Cart.findOne({ user: userId });
    if(!cart){
      cart = await Cart.create({ user: userId, items: [] });
    }
    const prod = await Product.findById(productId);
    if(!prod) return res.status(404).json({error: 'product not found'});
    const idx = cart.items.findIndex(i => i.product.toString() === productId);
    if(idx > -1){
      cart.items[idx].qty += qty || 1;
      cart.items[idx].price = prod.price;
    } else {
      cart.items.push({ product: productId, qty: qty || 1, price: prod.price });
    }
    cart.total = cart.items.reduce((s, it) => s + (it.qty * it.price), 0);
    await cart.save();
    res.json(cart);
  } catch (err) { next(err); }
};

export const removeFromCart = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    const { productId } = req.body;
    let cart = await Cart.findOne({ user: userId });
    if(!cart) return res.status(404).json({error: 'cart not found'});
    cart.items = cart.items.filter(i => i.product.toString() !== productId);
    cart.total = cart.items.reduce((s, it) => s + (it.qty * it.price), 0);
    await cart.save();
    res.json(cart);
  } catch (err) { next(err); }
};
