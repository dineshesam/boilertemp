import Product from '../models/Product.js';

export const listProducts = async (req, res, next) => {
  try {
    const products = await Product.find({});
    res.json(products);
  } catch (err) { next(err); }
};

export const getProduct = async (req, res, next) => {
  try {
    const p = await Product.findById(req.params.id);
    if(!p) return res.status(404).json({error: 'product not found'});
    res.json(p);
  } catch (err) { next(err); }
};

export const createProduct = async (req, res, next) => {
  try {
    const data = req.body;
    const p = await Product.create(data);
    res.json(p);
  } catch (err) { next(err); }
};

export const updateProduct = async (req, res, next) => {
  try {
    const p = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(p);
  } catch (err) { next(err); }
};

export const deleteProduct = async (req, res, next) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (err) { next(err); }
};
