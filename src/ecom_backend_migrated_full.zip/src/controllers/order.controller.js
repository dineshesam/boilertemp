import Order from '../models/Order.js';
import Cart from '../models/Cart.js';

export const createOrder = async (req, res, next) => {
  try {
    const { userId, shippingAddress, payment } = req.body;
    const cart = await Cart.findOne({ user: userId }).populate('items.product');
    if(!cart) return res.status(400).json({error: 'cart empty'});
    const items = cart.items.map(i => ({ product: i.product._id, title: i.product.title, qty: i.qty, price: i.price }));
    const total = cart.total;
    const order = await Order.create({ user: userId, items, shippingAddress, total, payment });
    cart.items = []; cart.total = 0; await cart.save();
    res.json(order);
  } catch (err) { next(err); }
};

export const listOrders = async (req, res, next) => {
  try {
    const orders = await Order.find({ user: req.params.userId });
    res.json(orders);
  } catch (err) { next(err); }
};
