import Wishlist from '../models/Wishlist.js';

export const getWishlist = async (req, res, next) => {
  try {
    const w = await Wishlist.findOne({ user: req.params.userId }).populate('products');
    if(!w) return res.json({ products: [] });
    res.json(w);
  } catch (err) { next(err); }
};

export const toggleWishlist = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    const { productId } = req.body;
    let w = await Wishlist.findOne({ user: userId });
    if(!w) w = await Wishlist.create({ user: userId, products: [] });
    const idx = w.products.findIndex(p => p.toString() === productId);
    if(idx > -1){
      w.products.splice(idx,1);
    } else {
      w.products.push(productId);
    }
    await w.save();
    res.json(w);
  } catch (err) { next(err); }
};
