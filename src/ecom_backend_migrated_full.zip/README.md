# Ecom Backend Migrated to MongoDB

This repository is a migrated scaffold converting a JSON-file based Node.js backend into a MongoDB (Mongoose) backend.

**What I produced:**
- `src/server.js` — Express app + Mongoose connection
- `src/models/*` — Mongoose models for User, Product, Cart, Order, Address, Wishlist
- `src/controllers/*` — rewritten controllers using Mongoose queries
- `src/routes/*` — routes that match typical endpoints from the original repo
- `src/data/` — copies of original JSON files found in your uploaded repo (used by migration script)
- `src/utils/migrateFromJson.js` — helper to import the JSON data into MongoDB
- `.env.example` — environment variables required
- `package.json` — scripts: `npm run dev`, `npm start`, `npm run migrate`

**How to run locally**
1. Copy `.env.example` to `.env` and fill in `MONGODB_URI` and other values.
2. `npm install`
3. `npm run dev` to run with nodemon, or `npm start` to run production.
4. Optionally, `npm run migrate` to import JSON files from `src/data` into MongoDB (make sure `MONGODB_URI` is set).

**Notes about keeping exact logic**
- Endpoints are preserved so your React Native app should work with minimal changes.
- Controllers implement behaviours: add-to-cart, remove-from-cart, create-order (that clears cart), wishlist toggle, address CRUD.
- Passwords from your JSON (if any) are imported into `passwordHash` field. If original stored plain passwords, check them — migration sets a placeholder if no hash was found.
- Product image URLs from Cloudinary are preserved in the `images` array so your RN app that expects Cloudinary URLs will continue working.
